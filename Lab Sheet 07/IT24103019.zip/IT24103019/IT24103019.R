setwd("C:\\Users\\USER\\Desktop\\2Y 1S\\PS\\Labs\\IT24103019")

#Q1
p1 <- punif(25, 0, 40) - punif(10, 0, 40)
cat("Q1 probability =", p1, "\n")

#Q2
p2 <- pexp(2, rate = 1/3)
cat("Q2 probability =", p2, "\n")

# Q3(i)
p3a <- 1 - pnorm(130, mean = 100, sd = 15)
cat("Q3(i) probability =", p3a, "\n")

# Q3(ii)
p3b <- qnorm(0.95, mean = 100, sd = 15)
cat("Q3(ii) 95th percentile =", p3b, "\n")
