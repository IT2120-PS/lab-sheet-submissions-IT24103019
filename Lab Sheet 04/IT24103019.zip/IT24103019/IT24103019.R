setwd("C:\\Users\\it24103019\\Desktop\\IT24103019")
getwd()
#q1
branch_data<- read.table("Exercise.txt" , header=TRUE , sep = ',')
head(branch_data)
fix(branch_data)
attach(branch_data)

#q2
str(branch_data)

#q3
boxplot(branch_data$Sales_X1,
        main = "Boxplot of Sales",
        ylab= "Sales",
        col= "lightblue")

#q4
fivenum(branch_data$Advertising_X2)
IQR(Advertising_X2)

#q5
find_outliers <- function(x){
  Q1<- quantile(x,0.25)
  Q3<- quantlie(x,0.75)
  iqr_val <- IQR(x)
  
  lower <- Q1 - 1.5*iqr_val
  upper <- Q3 +1.5 * iqr_val
  
  outliers <- x[x<lower | x>upper]
  return(outliers)
}

find_outliers(branch_data$Years_X3)

